import './App.css';
import Header from "./Layout/header";
import Footer from "./Layout/footer"
import Banner from './Components/banner';
import Offers from './Components/Offers';
import Brands from './Components/Brands';


function App() {
  return (
    <div className="App">
      <Header/>
      <Banner/>
      <Offers/>
      <Brands/>
      <Footer/>
    </div>
  );
}

export default App;
